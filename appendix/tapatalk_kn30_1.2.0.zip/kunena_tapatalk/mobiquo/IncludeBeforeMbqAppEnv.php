<?php

defined('MBQ_IN_IT') or exit;
/**
 * This file is not needed by default!
 * Run this first before call MbqMain::initAppEnv() when you need!
 * 
 * @since  2012-11-19
 * @author Wu ZeTao <578014287@qq.com>
 */
/* Please write any codes you need in the following area before call MbqMain::initAppEnv()! */



?>