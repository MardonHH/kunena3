<?php

defined('MBQ_IN_IT') or exit;

/**
 * cookie handle
 * 
 * @since  2012-7-2
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqCookie {
    
    public function __construct() {
    }
  
}

?>