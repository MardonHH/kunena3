<?php

defined('MBQ_IN_IT') or exit;

/**
 * session handle
 * 
 * @since  2012-7-2
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqSession {
    
    public function __construct() {
    }
  
}

?>