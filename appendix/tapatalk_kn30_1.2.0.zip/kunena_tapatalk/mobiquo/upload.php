<?php

require_once('mobiquo.php');

?>