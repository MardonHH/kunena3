<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActMMoveTopic');

/**
 * m_move_topic action
 * 
 * @since  2012-9-27
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActMMoveTopic extends MbqBaseActMMoveTopic {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>