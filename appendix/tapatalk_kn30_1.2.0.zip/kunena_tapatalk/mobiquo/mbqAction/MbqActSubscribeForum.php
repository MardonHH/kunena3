<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActSubscribeForum');

/**
 * subscribe_forum action
 * 
 * @since  2012-9-14
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActSubscribeForum extends MbqBaseActSubscribeForum {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>