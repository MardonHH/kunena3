<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActMApprovePost');

/**
 * m_approve_post action
 * 
 * @since  2012-9-28
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActMApprovePost extends MbqBaseActMApprovePost {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>