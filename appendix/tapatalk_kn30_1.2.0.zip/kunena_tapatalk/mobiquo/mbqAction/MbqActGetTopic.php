<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActGetTopic');

/**
 * get_topic action
 * 
 * @since  2012-8-7
 * @author Wu ZeTao <578014287@qq.com>
 */
Class MbqActGetTopic extends MbqBaseActGetTopic {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement() {
        parent::actionImplement();
    }
  
}

?>